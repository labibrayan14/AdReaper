Steps to build `cm6.bundle.AdReaper.min.js` -- command line:

- `git clone https://github.com/Labibrayan14/codemirror-quickstart.git`
    - This is a customized repo forked from <https://github.com/RPGillespie6/codemirror-quickstart>
- `cd codemirror-quickstart`
- `npm install`
- `npm build`
- `cm6.bundle.AdReaper.min.js` should be in `dist` directory
- This is the origin of the `cm6.bundle.AdReaper.min.js` in the current directory
